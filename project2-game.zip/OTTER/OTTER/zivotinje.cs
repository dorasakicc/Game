﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OTTER
{
    public class zivotinje:Sprite
    {
       public bool Aktivan { get; set; }

        private int bodoviVrijednost;
        public int BodoviVrijednost
        {
            get { return bodoviVrijednost; }
            set { bodoviVrijednost = value; }
        }

       
        public zivotinje(string slika, int x, int y)
    : base(slika, x, y)
        {
            Aktivan = false;
            
            this.BodoviVrijednost = 100;
        }
       
    }
}
