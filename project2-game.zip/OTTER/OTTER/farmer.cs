﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OTTER
{
    public class Farmer : Sprite
    {
        
        
        public delegate void EventHandler();
        public event EventHandler Krajigre;
        private int bodovi;
        public int Bodovi
        {
            get { return bodovi; }
            set
            {
                bodovi = value;
                if (bodovi ==800)
                    Krajigre.Invoke();
            }
        }
        private int zivoti;
        public int Zivoti
        {
            get { return zivoti; }
            set
            {
                zivoti = value;
                if (zivoti <= 0)
                    Krajigre.Invoke();
            }
        }
        
        public Farmer(string pic, int x, int y)
      : base(pic, x, y)
        {
            
            Bodovi = 0;
            Zivoti = 3;
        }
        public bool TouchingSprite(zivotinje t)
        {
            Sprite s = t;
            if (this.TouchingSprite(s))
            {
                t.Aktivan = false;
                this.Bodovi += t.BodoviVrijednost;
                return true;
                t.SetVisible(false);
            }
            return false;
        }
       
       

        public bool TouchingSprite(automobili t)
        {
            Sprite s = t;
            if (this.TouchingSprite(s))
            {
                t.Aktivan = false;
               
                return true;



            }
            return false;
        }







    }
}

