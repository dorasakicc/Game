﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OTTER
{
   public class automobili:Sprite
    {
        private string rub;
        public string Rub
        {
            get { return rub; }
            set { rub = value; }
        }
        public delegate void EventHandler();
        public event EventHandler Krajigre;
       
        public event EventHandler GubiZivot;

        public override int X
        {
            get { return base.X; }
            set
            {
                if (value + this.Width > GameOptions.RightEdge)
                {
                    base.x = GameOptions.RightEdge - this.Width;
                    this.Rub = "desno";
                }
                else if (value < 0)
                {
                    base.x = 0;
                    this.Rub = "lijevo";
                    
                }
                else
                {
                    base.x = value;
                    this.Rub = "";
                }
            }
        }
        public bool Aktivan { get; set; }
        
      

        private int brzina;
        public int Brzina
        {
            get { return brzina; }
            set { brzina = value; }
        }
        public void MoveSteps()
        {
            this.X += this.Brzina;
        }

        public automobili(string pic, int x, int y)
      : base(pic, x, y)
        {
            Rub = "";
           Aktivan = false;
            Brzina = 10;
            
            
        }
       
    }
}
